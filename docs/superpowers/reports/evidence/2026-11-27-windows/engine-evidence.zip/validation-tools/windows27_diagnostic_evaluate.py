import json,re,subprocess
from pathlib import Path
s=Path(__file__).parent;r=Path('C:/Users/Admin/.codex/worktrees/godot-windows-20261127');e=s/'windows-20261127-other';p=e/'progress.json';d=json.loads(p.read_text(encoding='utf8'))
scenes=['ContentRegistryRuntimeModuleProof','CoreDamageRuntimeModuleProof','GameConfigRuntimeModuleProof','NodeBindingRuntimeModuleProof','SsotAccessorRuntimeModuleProof']
for sc in scenes:
 x=next(x for x in d['results'] if x['scene']==sc);k=x['keys']
 def source(path):return subprocess.check_output(['git','show',x['sha']+':'+path],cwd=r,text=True,encoding='utf8')
 paths=[]
 if sc=='ContentRegistryRuntimeModuleProof':
  reg='godot-mindustry/src/generated/GeneratedClassRegistry.gd';defaults='godot-mindustry/src/game/SourcePlayableContentDefaults.gd';paths=[reg,defaults,'godot-mindustry/src/game/SourceContentRegistryRuntimeState.gd','godot-mindustry/src/game/SourceGeneratedClassRuntime.gd']
  total=int(re.search(r'const CLASS_COUNT := (\d+)',source(reg))[1]);selected=json.loads(re.search(r'func selected_generated_class_names\(\).*?return (\[[^\n]+\])',source(defaults),re.S)[1])
  expected={'module':'SourceContentRegistryRuntimeState','content_catalog_loaded':True,'content_counts_match':True,'generated_class_count':total,'all_generated_script_count':total,'selected_generated_script_count':len(selected),'selected_generated_instance_count':len(selected),'load_failures':0,'instance_failures':0,'one_headquarter_per_ssot':True,'registry_valid':True}
 elif sc=='CoreDamageRuntimeModuleProof':
  paths=['godot-mindustry/src/game/SourceCoreDamageRuntimeState.gd','godot-mindustry/src/game/SourceGameOverCoreDestroyedState.gd']
  expected={'module':'CORE_DAMAGE_RUNTIME_MODULE_PROOF','wrapper_matches':True,'module_wrapper_matches':True,'applied':10.0,'core_health_after':0.0,'core_damage_taken_total_after':12.0,'game_over':True,'winner':'','game_over_triggered':True,'registry_valid':True,'one_headquarter_per_ssot':True}
 elif sc=='GameConfigRuntimeModuleProof':
  paths=['godot-mindustry/src/generated/playable_content.json','godot-mindustry/src/game/SourceGameConfigRuntimeState.gd'];tile=json.loads(source(paths[0]))['tile_size']
  expected={'module':'SourceGameConfigRuntimeState','config_loaded':True,'tile_size':tile,'config_tile_size':tile,'tile_size_matches':True,'one_headquarter_per_ssot':True,'registry_valid':True}
 elif sc=='NodeBindingRuntimeModuleProof':
  expected={'module':'SourceNodeBindingRuntimeState','camera_bound':True,'hud_label_bound':True,'hud_label_position_matches':True,'one_headquarter_per_ssot':True,'registry_valid':True}
 else:
  expected={'module':'SourceSsotAccessorRuntimeState','source_matches_module':True,'source_symbol_loaded':True,'asset_manifest_loaded':True,'one_headquarter_per_ssot':True,'registry_valid':True}
 assert k==expected,(sc,k,expected)
 assert not x['errors'] and x['targeted']['exit'] in [0,None],sc
 original=e/(sc+'-original-classification.json')
 if not original.exists():original.write_text(json.dumps(x,indent=2),encoding='utf8')
 x['evaluation']={'kind':'external exact payload comparison; scene has no aggregate matches field','expected':expected,'source_paths':paths,'note':'Existing boolean checks all true. Counts follow committed registry/defaults; core damage clamps 15 to remaining health 10 and accumulates prior 2 to 12. No scene edits.'}
 for path in paths:x['source_blobs'][path]=subprocess.check_output(['git','rev-parse',x['sha']+':'+path],cwd=r,text=True).strip()
 x['windows_pass']=True
 (e/(sc+'-external-evaluation.json')).write_text(json.dumps(x['evaluation'],indent=2),encoding='utf8')
p.write_text(json.dumps(d,indent=2,ensure_ascii=False),encoding='utf8');print(json.dumps({'externally_validated':scenes}))
