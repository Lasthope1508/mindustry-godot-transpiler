# Resume notes 2026-11-27

- User requested latest repo missing Windows tests. Schedule remains PAUSED. No subagents.
- Active sequential engine cell: functions cell 1206. WAIT this cell; do not launch another engine. Previous 1181 ended due MCP losing quick-exit scene logs.
- First queue: windows-20261127/progress.json, 368 C07 scenes at main 375736358640ef3d2e8db58bae4032be3e199b75. At note time 120/120 PASS. Runner windows27.py updates checkpoint after every result.
- Quick-exit scenes use windows27_quick_native.py: actual graphical Windows exe, stdout/stderr/exit retained, no --headless. Other scenes use MCP graphical run/debug/stop. C07GameHeadless metadata module string initially misclassified; original recorder RED retained; assertions were all true and recorder corrected metadata handling. No proof/source edits.
- Resume orchestration SAVED ON DISK: windows27Batch.js and windows27OtherBatch.js under task-state root. Functions store changes from a running cell may not be visible until completion; use disk scripts if resuming. Disk scripts load compact queue + completed scene identities to avoid JSON output truncation.
- Prepared SECOND queue (not started): windows-20261127-other/progress.json. 315 non-C07 scenes inventoried; 46 accepted historical Windows with direct dependency hashes unchanged versus 516ac38; 41 historical scenes with changed dependencies plus no-matching-evidence scenes ->269 queued. 56 have no existing targeted module; run native only and label accurately. Others run existing modules. Generic recorder matches=true + targeted pass/no existing module + no runtime/parser errors. Handles duplicate identical proof prints.
- Run windows27OtherBatch.js only AFTER first queue completes and any desired controlled main update. Its base is still375736358; if updating checkout before launch update base accordingly and preserve first queue immutable evidence.
- Main fetched again:06efa214ef015e357d97ae06d80d236c1ce5bece, adds only N2484 BuildTurretBuild.sense and proof C07BuildTurretSenseProof. Saved main-delta.json. Must audit/test additions after immutable first batch, plus relevant neighbors, without changing source under active engine.
- Worktree C:/Users/Admin/.codex/worktrees/godot-windows-20261127 on codex/windows-validation-20261127. Import noise2558 tracked .import/project files; preserve/exclude exact staging. No commits yet. Upstream dirs are junctions to prior worktree pinned Java sources.
- Initial publisher windows27_publish.py is NOT READY for combined queues: only C07, claim all MCP outdated, needs raw evidence revalidation, mixed snapshot/metadata/native-only/accepted46 reporting, latest main delta results, zip namespaces and manifests before run. Do not run unedited.
- Publication API helper github_validation_api.py (credentials private), review_all_debt.py only reference (old branch/path). Publish only own report/evidence, attach PR immediately, review diff allowlist, account/head/main/checks/protection/rules/mergeability and own merge. Preserve historical wave36 15 RED; no global GAME GREEN claim.
- Keep running through all queued proof work; don't stop after a batch. Checkpoint after each result; final update coverage/PR/pending + release owned run.lock after cleanup. No schedule restart.
- Memory used MEMORY.md17-24; final requires memory citation block with these lines, empty rollout_ids allowed.

## Latest recovery update

- First batch COMPLETE:368/368 PASS at375736358. Cell1206 finished.
- Active cell1240 runs latest10 BuildTurret proofs/neighbors, then other269 sequentially. WAIT1240; no competing engine.
- Worktree FF main5dd2907ce1569da48eb1d59f326996b536256dc2 (N2484 sense, N2485 senseObject; only additions to SourceBuildTurretBuildState, old methods unchanged). Latest/other queue bases updated to5dd2907ce; accepted46 rechecked unchanged.
- Publisher to use is windows27_prepare_publication.py (not old windows27_publish.py), requires config created only after all runs/delta audit complete. Review helper windows27_review_pr.py ready. Auth verified Lasthope1508/admin/push.
